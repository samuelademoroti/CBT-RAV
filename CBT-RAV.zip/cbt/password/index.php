<?php
include '../session/index.php';

$studentId = $_SESSION['user']['id'];
$checkBefore = $port->prepare('SELECT *, COUNT(*) AS numrow FROM password WHERE student_id=:student_id');
$checkBefore->execute(['student_id' => $studentId]);
$fetchChecked = $checkBefore->fetch();
if($fetchChecked['numrow'] > 0){
    header('Location: ../index.php');
    exit();
}
else{
    $setPasswordPage = "";
    $setPasswordPage .= "<!DOCTYPE html>
    <html lang='en'>";
    include '../includes/head.php';
    $setPasswordPage .= "
    <body>
    <div class='setPassowd'>
    <div class='imgLogo'>
    <img src='../samuelAdemoroti.png'>
    </div>
    <h1>Welcome ".$_SESSION['user']['name']."</h1>
    <h2>Set Password</h2>";
    
    if(isset($_SESSION['error'])){
        $setPasswordPage .= "<p style='color: red;'>".$_SESSION['error']."</p>";
        unset($_SESSION['error']);
    }
    
    $setPasswordPage .= "
    <form method='post' action='../initialize/'>
        <input type='hidden' name='type' value='setpassword'>
        <label for='password'>New Password:</label>
        <input type='password' id='password' name='password' required><br>
        <button type='submit'>Set Password</button>
    </form>
    </div>
    </body>
    </html>";
    
    print($setPasswordPage);
}

?>
<style>
    
    .setPassowd{
       width: 100%;
       height:100%; 
       display:flex;
       justify-content:center;
       align-items:center;
       flex-direction:column;
    }
h1{
    text-align: center;
    color: #333;
    margin-bottom:5px;
}
h2{
    text-align: center;
    color: #555;
    margin-bottom:5px;
}
.imgLogo{
    background:rgba(0,0,0,0.05);
    border-radius:10px;
    padding:2px 5px;
    margin-bottom:10px;
}
.imgLogo img{
    height:100px;
    width:100px;
}
form {
    width: 300px;
    margin: 0 auto;
    text-align: center;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 10px;
}
label {
    display: block;
    margin-bottom: 10px;
}
input[type="password"] {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
}
button {
    width: 100%;
    padding: 10px;
    background-color: #da2c2c;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}
</style>