<?php
include('../session/index.php');
if($_SESSION['user']){
    
    $stmt = $port->prepare('SELECT *, COUNT(*) AS numrow FROM final_result WHERE student_id=:id');
    $stmt->execute(['id'=>$_SESSION['user']['id']]);
    $score = $stmt->fetch();
    if($score['numrow'] == 0){
        header('Location: ../logout.php');
        exit();
    }

    $video = $_SESSION['video'] ;
    $ffmpegpath = "C:/ffmpeg/bin/ffmpeg.exe";
    // developed by Samuel Ademoroti
    $command = "{$ffmpegpath} -i {$video} -af 'volumedetect' -f null - 2>&1";
    $mean = null;
    $max = null;
    exec($command, $output, $return_code);
    foreach($output as $row){
      if(strpos($row, 'mean_volume')){
        if(preg_match("/mean_volume: ([-0-9.]+) dB/", $row, $match)){
          $mean = $match[1];
        }
      }
      if(strpos($row, 'max_volume')){
        if(preg_match("/max_volume: ([-0-9.]+) dB/", $row, $maxmatch)){
          $max =$maxmatch[1];
        }
      }
    }
    if(($mean <= -40.00 && $mean >= -60.00) && ($max <= -30.00 && $max >= -40.0 )){
      $malpractice = "no";
    }
    else{
      $malpractice = "yes";
    }
    //if you wnat full code, just find me and text me 'SAMUEL DAMOLA ADEMOROTI'

    $pageScore="";
    $pageScore ="<html>";
    include "../includes/head.php";
    if($score['malpractice'] == "yes"){
        $result = "<p class='score'>Your score is ".$score['score']."</p>";
    }else{
        $result = "<p class='malpracise'>You were involve in examination malpractice. See the Chief Examiner for result.</p>";
    }
    $pageScore.="
    <div class='scoresheet'>
    <div class='sheet'>
    <div class='sheet_img'>
    <img src='../samuelAdemoroti.png'>
    </div>
    <p class='coursename'>COS 102 Introduction to Computing</p>
    $result
    <div class='scoresheet_logoutDiv'><a class='scoresheet_logout' href='../logout.php'>Logout</a></div>
    </div>
    </div>
    ";
   $pageScore.="</html>";
}
print($pageScore);
?>
<style>
    .malpracise{
        width:100%;
        float:left;
        font-size:20px;
        text-align:center;
    }

    .score{
        width:100%;
        float:left;
        font-size:20px;
        text-align:center;
    }

.scoresheet{
    width: 100%;
    height:100%;
    display:flex;
    justify-content:center;
    align-items:center;
}
.scoresheet_logoutDiv{
    width:100%;
    float:left;
    margin-top:10px;
    padding:5px;
    padding:10px;
    text-align:center;
}
.scoresheet_logout{
    background:#da2c2c;
    text-decoration:none;
    padding:5px 10px;
    color:#ffffff;
    border-radius:5px
}
.scoresheet_logout:hover{
    background:#ffffff;
    border:1px solid #da2c2c;
    color:#da2c2c;
}
.sheet{
    width:50%;
    border-radius:10px;
    padding:10px;
    background:rgba(0,0,0,0.05);
}
.sheet_img{
    width:100%;
    float:left;
    font-size:20px;
    text-align:center;
}
.sheet_img img{
    height:150px;
}

.coursename{
    width:100%;
    float:left;
    font-size:20px;
    text-align:center;
    padding:10px;
    font-weight:bold;
}
</style>    