<?php
include "session/index.phph";
header('Location: run');
?>