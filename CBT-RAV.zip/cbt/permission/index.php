<?php
print('Accept The Cookies-- to be designed');
?>