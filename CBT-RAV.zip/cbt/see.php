<?php
include 'session/index.php';
header('Content-Type:application/json');
$d = file_get_contents("php://input");
$data = json_decode($d);
$id = 13;
$delete = $port->prepare("DELETE FROM questions WHERE id=:id");
$delete->execute(['id'=>$id])

?>