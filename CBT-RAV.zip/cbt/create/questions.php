<?php
include '../session/index.php';
$fetchALL = $port->prepare("SELECT * FROM questions ORDER BY id DESC");
$fetchALL->execute();
$response = $fetchALL->fetchAll();
echo json_encode($response);

?>