<?php
include '../session/index.php';
header('Content-Type:application/json');
$qData = file_get_contents("php://input");
$qdata = json_decode($qData, true);
$id = $qdata['questionId'];
$getQ = $port->prepare("SELECT * FROM questions WHERE id=:id");
$getQ->execute(['id'=>$id]);
$fetchedQ = $getQ->fetch();
$a = ['A','B', 'C','D'];
$select ="";
$select .="<div class='answerOption'>
            <select id='qAnswer'>";
foreach($a as $row){
if($row == $fetchedQ['correct_option']){
$select .= "<option value='".$row."' selected>".$row."</option>";
}
else{
$select .= "<option value='".$row."'>".$row."</option>";
}
}
$select .="</select></div>";
$echo  = ' <div class="textarea">
                            <textarea id="qValue" placeholder="Enter Question">'.$fetchedQ['question'].'</textarea>
                        </div>
                        <div class="optionList">
                        <div class="option">
                            <input type="text" placeholder="Option A" id="optionA" value="'.$fetchedQ['option_a'].'">  
                        </div>
                        <div class="option">
                            <input type="text" placeholder="Option B" id="optionB" value="'.$fetchedQ['option_b'].'">  
                        </div>
                        <div class="option"> 
                            <input type="text" placeholder="Option C" id="optionC" value="'.$fetchedQ['option_c'].'"> 
                        </div>
                        <div class="option">
                            <input type="text" placeholder="Option D" id="optionD" value="'.$fetchedQ['option_d'].'"> 
                        </div>
                        
                        '.$select.'
                        
                        </div>
                        <div class="submitQA"> 
                        <input type="button" class="editQA" data-id="'.$id.'" value="Edit">  
                        </divd>
        ';


print($echo);
?>