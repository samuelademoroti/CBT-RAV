<?php
header("conten-Type: application/json");
include '../session/index.php';
$data = file_get_contents("php://input");
$d =  json_decode($data, true);
$question = $d['qs'];
$answer = $d['qa'];
$a = $d['a'];
$b = $d['b'];
$c = $d['c'];
$d = $d['d'];
try{
$addQuestion = $port->prepare("INSERT INTO questions (question, option_a, option_b, option_c, option_d, correct_option) VALUES (:question, :a, :b, :c, :d, :answer)");
$addQuestion->execute(["question"=>$question, "a"=>$a, "b"=>$b, "c"=>$c, "d"=>$d, "answer"=>$answer]);
 $response = ['status'=>'success'];
}
catch(Exception $e){
    $error = "Error".$e->getMessage();
    $response = ['status'=>$error];
}
echo json_encode($response);
?>