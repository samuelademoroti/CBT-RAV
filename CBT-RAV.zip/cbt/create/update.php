<?php
include "../session/index.php";
header('Content-Type:application/json');
$rawData = file_get_contents("php://input");
$data = json_decode($rawData, true);
$a =$data['optionA'];
$b =$data['optionB'];
$c =$data['optionC'];
$d =$data['optionD'];
$qa =$data['qAnswer'];
$q = $data['qValue'];
$id = $data['editID'];
try{
$updateQ = $port->prepare('UPDATE questions SET question=:q, option_a=:a, option_b=:b, option_c=:c, option_d=:d, correct_option=:qa WHERE id=:id');
$updateQ->execute(['a'=>$a,'b'=>$b, 'c'=>$c, 'd'=>$d, 'q'=>$q, 'qa'=>$qa, 'id'=>$id]);
}
catch(Exception $e){
    $error = $e->getMessage();
    echo json_encode($error);
}
?>
