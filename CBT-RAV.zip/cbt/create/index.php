<?php
include '../includes/head.php';
?>

<html>
    
    <body>
        <div class="h1cell"><h1><i class="fa-solid fa-clipboard-question"></i> Questions.</h1></div>
         <div class="qUnitcell">
            <div class="qUnitblock">
            <p>Number of  Questions</p>
            <p id="qUnit"></p>
            </div>   
         </div> 
        <div class="addQdiv">
            <button id="addQuestion"><i class="fa-solid fa-plus"></i> Add Question</button>
        </div>
     <div class="questionList">
        <div>
            <h1><i class="fa-solid fa-list-check"></i> Question List</h1>
        </div>
        <div class="data">
            
        </div>
     </div>

        <div class="questionModal">
            <div class="qM1">
                <div class="qM1head"> <button id="closeQM"><i class="fa-regular fa-arrow-left"></i></button></div>
                <div class="qM1content">
                    <div class="qMh1">
                        <h1>New Question</h1>
                    </div>
                    <form id="addNewQ">
                        <div class="textarea">
                            <textarea id="qValue" placeholder="Enter Question"></textarea>
                        </div>
                        <div class="optionList">
                        <div class="option">
                            <input type="text" placeholder="Option A" id="optionA">  
                        </div>
                        <div class="option">
                            <input type="text" placeholder="Option B" id="optionB">
                        </div>
                        <div class="option"> 
                            <input type="text" placeholder="Option C" id="optionC"> 
                        </div>
                        <div class="option">
                            <input type="text" placeholder="Option D" id="optionD"> 
                        </div>
                        <div class="answerOption">
                            <select id="qAnswer">
                                <option>Select Answer</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                            </select>
                        </div>
                        </div>
                        <div class="submitQA"> 
                        <input type="button" id="submitQA" value="Submit">  
                        </divd>
                    </form>


                </div>
            </div>
        </div>

        
    </body>
    
    <style>
        .questionList{
            width:100%;
            float:left;
            margin-top:10px;
            background:#fbe9e9;
            padding:20px;
            height: calc(100vh - 243px);
        }
        .data{
            width:100%;
            height:auto;
            padding:10px;
        }
        .qUnitcell{
            float:left;
            width:100%;
            padding:10px 20px;  
            height:auto;       
        }
        .qUnitblock{
            float:left;
            padding:10px;
            background:pink;
            border-radius:10px;
            box-shadow:2px 2px 4px rgba(0,0,0,0.1);
        }
        .qUnitblock p{
            float:left;
            padding:5px;
            width:100%;
            text-align:center;
        }
        
        .qUnitblock p:first-child{
            border-bottom:1px dotted #da2c2c;
        }
        #qUnit{
            font-size:22px;
            font-weight:bold;
            padding: 5px;
        }
        .h1cell{
            padding:15px 20px;
            width:100%;
            float:left;
        }

        .addQdiv{
            width:100%;
            float:left;
            padding:10px 20px;
        }

        #addQuestion{
            padding:10px;
            border-radius:10px;
            border:none;
            box-shadow:0 2px 4px rgba(0, 0, 0, 0.1);
            font-size:18px;
        }
        
        #addQuestion i{
            color:#da2c2c;
        }

        *{
            box-sizing:border-box;
            margin:0px;
            padding:0px;
        }
        .questionModal{
            width:100%;
            height:100%;
            background:rgba(0, 0, 0, 0.5);
            position:absolute;
            top:0px;
            display:none;
        }
        .qM1{
            width:100%;
            height:100%;
        }
        .qM1head{
            width:100%;
            float:left;
            height:30px;
            padding:2px;
            background:#ffffff;
        }
        .qMh1{
            width:100%;
            float:left;
            padding:10px 20px;
            text-align:center;
        }
        .qMh1 h1{
            font-size:24px;
            color:#333;
            text-shadow: 1px 1px #ec9393;
        }
        
        #closeQM{
            float:left;
            border:none;
            height:100%;
            border-radius:50%;
            padding:0px 5px;
            background:none;
        }
        
        #closeQM:hover{
            background:rgba(0,0,0,0.1);
        }

        .qM1content{
            float:left;
            width:100%;
            padding:10px;
            background:#ffffff;
        }
        .textarea{
            width:100%;
            float:left;
            padding:10px;
        }

        
        .textarea textarea{
            width:100%;
            height:100px;
            float:left;
            padding:10px;
            resize:none;
            border-radius:10px;
            border:none;
            background:rgba(0,0,0,0.05);
            box-shadow:  inset 2px 2px 4px #BABECC, inset -3px -3px 6px  #FFF;
        }
        .optionList{
            width:100%;
            float:left;
        }
        .option{
            width:50%;
            float:left;
            padding:10px;
        }
        
        .option input{
            width:100%;
            float:left;
            padding:10px;
            border-radius:5px;
            border:none;
            background:rgba(0,0,0,0.05);
            box-shadow:  inset 2px 2px 4px #BABECC, inset -3px -3px 6px  #FFF;
        }
        .answerOption{
            width:100%;
            float:left;
            text-align:center;
        }
        
        .answerOption select{
            width:auto;
            padding:10px 20px;
            border-radius:5px;
            border:none;
            background:rgba(0,0,0,0.05);
            box-shadow:  inset 2px 2px 4px #BABECC, inset -3px -3px 6px  #FFF;
        }
        .submitQA{
            width:100%;
            float:left;
            padding:10px;
            text-align:center;
        }
        
        .submitQA input{
            width:auto;
            padding:10px 20px;
            text-align:center;
            border-radius:10px;
            border:none;
            background:#da2c2c;
            color:#ffffff;
        } 
         .submitQA input:hover{
            border:1px solid #da2c2c;
            background:#ffffff;
            color:#da2c2c;
        }

        .qList{
            width:100%;
            float:left;
            padding:5px;
        }
        .qSet{
            width:100%;
            float:left;
            padding:5px;
        }

        .qCall{
            width:auto;
            float:left;
            padding:5px;
            border-radius:10px;
            background:#f2f2f2;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        
        .qCall p{
            width:100%;
            float:left;
            padding:5px;
            font-size:18px;
        }
        .qBtn{
            width:100%;
            float:left;
            padding:5px 20px;
        }
        
        .qBtn button{
            float:left;
            padding:5px;
            margin-right:20px;
            border-radius:5px;
            border:none;
            padding:3px 7px;
            background: #ffffff;
        }
        
        
        .qBtn button:first-child i{
            color: #ffe033;
           
        }
        
        .qBtn button:last-child i{
            color: #da2c2c;
        }
        
        .qBtn button:first-child:hover{
            background: #ffe033;
            color:#ffffff;
        }
        
        .qBtn button:last-child:hover{
            background: #da2c2c;
            color:#ffffff;
        }
        .loader {
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid #da2c2c;
  width: 15px;
  height: 15px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
    </style>

    <script>
    const questionModal = document.querySelector('.questionModal');
    const addQuestion = document.getElementById('addQuestion');
    const closeQM = document.getElementById('closeQM');
    addQuestion.addEventListener('click', ()=>{
        document.getElementById('addNewQ').reset();
        questionModal.style.display = "block";
    });
    closeQM.addEventListener('click', ()=>{
       closeQmodal();
    });

    function closeQmodal(){
        questionModal.style.display = "none"; 
    }
    const newQuestion = document.getElementById('newQuestion');
    const submitQA = document.getElementById('submitQA');
    const qAnswer = document.getElementById('qAnswer');
    const optionA = document.getElementById('optionA');
    const optionB = document.getElementById('optionB');
    const optionC = document.getElementById('optionC');
    const optionD = document.getElementById('optionD');
    const qValue = document.getElementById('qValue');
    submitQA.addEventListener('click', ()=>{
        const qa = qAnswer.value;
        const a = optionA.value;
        const b = optionB.value;
        const c = optionC.value;
        const d = optionD.value;
        const qs = qValue.value;
        fetch('insert.php', {
            method: 'POST',
            header: {'content-Type':'application/json'},
            body: JSON.stringify({qs:qs, qa:qa, a:a, b:b, c:c, d:d})
        }).then(response=>response.json()).then(data =>{
            console.log(data);
            if(data.status =='success'){
                console.log(data.status);
                document.getElementById('addNewQ').reset();
                closeQmodal();
            }
        }).catch(error =>{
            console.error(error);
        })
    });
    function fetchQ(){
        const dtaDiv = document.querySelector(".data");
        fetch('questions.php').then(response=>response.json()).then(data=>{
            const qUnit = document.getElementById('qUnit');
            if(data.length > 0){
                qUnit.innerHTML = data.length ;
            }else{
                qUnit.innerHTML = 'No question';
            }
            data.forEach(element => {
               console.log(element);
               const dataDiv = document.createElement('div');
               dataDiv.classList.add('qList');
               dataDiv.innerHTML = `<div class="qSet" id="remove${element.id}"><div class="qCall"><p>${element.id}. ${element.question}</p><div class="qBtn"><button class="qedit" value="${element.id}"><i class="fa-solid fa-pen-fancy"></i> Edit</button><button class="qdelete" value="${element.id}"><i class="fa-solid fa-trash"></i> Delete</button></div></div></div>`;
               dtaDiv.prepend(dataDiv);
              
            });
        }).catch(error=>{
            console.error(error);
        });
        }
        


    window.addEventListener('load', ()=>{
        fetchQ();
    })

    

    document.addEventListener('click', function(e){
        const qedit = e.target.closest('.qedit');
        const editQA = e.target.closest('.editQA');
        const qdelete = e.target.closest('.qdelete');
        if(qedit){
            let questionId = qedit.value;
            fetch('getQuestion.php', {
                method:'POST',
                header:{'content-Type':'application/json'},
                body: JSON.stringify({questionId:questionId})
                
            }).then(response=>response.text()).then(data=>{
                questionModal.style.display = "block";
                document.getElementById('addNewQ').innerHTML = data;
            }).catch(error=>{
                console.log(error);
            })
        }
        if(editQA){
            alert("Edit");
            let editID = editQA.getAttribute('data-id');
            let qAnswer = document.getElementById('qAnswer').value;
            let optionA = document.getElementById('optionA').value;
            let optionB = document.getElementById('optionB').value;
            let optionC = document.getElementById('optionC').value;
            let optionD = document.getElementById('optionD').value;
            let qValue = document.getElementById('qValue').value;
            alert(qAnswer+" "+optionA+" "+optionB+" "+optionC+" "+optionD+" "+qValue);
            fetch('update.php', {
                method:'POST',
                header: {'content-Type':'application/json'},
                body: JSON.stringify({qAnswer:qAnswer, optionA:optionA, optionB:optionB, optionC:optionC, optionD:optionD, qValue:qValue, editID:editID})
            }).then(response=>response.text()).then(data=>{
                console.log(data);
            }).catch(error=>{
                console.log(error);
            })
        }
        if(qdelete){
            qdelete.innerHTML = '<div class="loader"></div>';
            let id = qdelete.value;
            let that = "remove"+id;
            let toRemove = document.getElementById(that);
            fetch('delete.php',{
                method: 'POST',
                header: {'content-Type':'application/json'},
                body:JSON.stringify({id:id})
            }).then(response=>response.json()).then(data=>{
                if(data == "success"){
                    setTimeout(()=>{
                        toRemove.remove();
                    },1000)
                    
                }
                else{
                    qdelete.innerHTML = "Delete";
                }
                console.log(data);
            }).catch(error=>{
                console.log(error);
            })
            
        }

    })
    </script>
</html>