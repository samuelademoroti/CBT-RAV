<?php
include '../session/index.php';
header('Content-Type:application/json');
$qData = file_get_contents("php://input");
$qdata = json_decode($qData, true);
$id = $qdata['studentId'];
$getQ = $port->prepare("SELECT * FROM students WHERE id=:id");
$getQ->execute(['id'=>$id]);
$fetchedQ = $getQ->fetch();
$getP = $port->prepare("SELECT * FROM department");
$getP->execute();
$prog = $getP->fetchAll();
$select ="";
$select .="<div class='answerOption'>
            <label>Programme</label>
            <select id='studentProgramme'>";
foreach($prog as $row){
if($row['id'] == $fetchedQ['programme']){
$select .= "<option value='".$row['id']."' selected>".$row['name']."</option>";
}
else{
$select .= "<option value='".$row['id']."'>".$row['name']."</option>";
}
}
$select .="</select></div>";
$echo  = '<div class="option">
            <input type="text" placeholder="Name" id="studentName" value="'.$fetchedQ['name'].'">
          </div>
          <div class="option">
            <input type="text" placeholder="Maric Number" id="matricNumber" value="'.$fetchedQ['matric_number'].'">
          </div>
          '.$select.'
          </div>
          <div class="submitQA">
          <input type="button" class="editStudent" data-id="'.$id.'" value="Edit">  
</div>';


print($echo);
?>