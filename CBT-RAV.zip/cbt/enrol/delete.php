<?php
include '../session/index.php';
header('Content-Type:application/json');
$d = file_get_contents("php://input");
$data = json_decode($d, true);
$id = $data['id'];
try{
$delete = $port->prepare("DELETE FROM students WHERE id=:id");
$delete->execute(['id'=>$id]);
$res = "success";
}
catch(Exception $e){
$res ="Error".$e->getMessage();
}
echo json_encode($res)
?>