<?php
include "../session/index.php";
header('Content-Type:application/json');
$rawData = file_get_contents("php://input");
$data = json_decode($rawData, true);
$studentName = $data['studentName'];
$matricNum = $data['matricNum'];
$programme = $data['studentProgramme'];
$id = $data['editID'];
try{
$updateQ = $port->prepare('UPDATE students SET name=:studentName, matric_number=:matricNum, programme=:studentProgramme WHERE id=:id');
$updateQ->execute(['studentName'=>$studentName,'matricNum'=>$matricNum, 'studentProgramme'=>$programme, 'id'=>$id]);
$response = "success";
echo json_encode($response);
}
catch(Exception $e){
    $error = $e->getMessage();
    echo json_encode($error);
}
?>
