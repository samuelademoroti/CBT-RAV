<?php
header("conten-Type: application/json");
include '../session/index.php';
$data = file_get_contents("php://input");
$d =  json_decode($data, true);
$studentName = $d['studentname'];
$matricNum = $d['matricnum'];
$programme = $d['program'];
try{
$addQuestion = $port->prepare("INSERT INTO students (name, programme, matric_number) VALUES (:name, :programme, :matric_number)");
$addQuestion->execute(["name"=>$studentName, "programme"=>$matricNum, "matric_number"=>$programme]);
 $response = ['status'=>'success'];
}
catch(Exception $e){
    $error = "Error".$e->getMessage();
    $response = ['status'=>$error];
}
echo json_encode($response);
?>