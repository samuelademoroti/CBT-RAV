<?php
include '../includes/head.php';
?>

<html>
    
    <body>
        <div class="h1cell"><h1><i class="fa-solid fa-clipboard-list"></i>Enrol.</h1></div>
         <div class="sUnitcell">
            <div class="sUnitblock">
            <p>Number of  Students</p>
            <p id="sUnit"></p>
            </div>   
         </div> 
        <div class="addQdiv">
            <button id="addStudent"><i class="fa-solid fa-person-circle-plus"></i> Enrol Student</button>
        </div>

        <div class="enrolledD">
        <div>
            <h1><i class="fa-solid fa-list-check"></i> Enrolled students</h1>
        </div>
        <div class="data">
            
        </div>
        </div>
        <div class="studentModal">
            <div class="sM1">
                <div class="sM1head"> <button id="closeQM"><i class="fa-regular fa-arrow-left"></i></button></div>
                <div class="sM1content">
                    <div class="qMh1">
                        <h1>New Student</h1>
                    </div>
                    <form id="addNewQ">
                        <div class="optionList">
                        <div class="option">
                            <input type="text" placeholder="Name" id="studentName">  
                        </div>
                        <div class="option">
                            <input type="text" placeholder="Maric Number" id="matricNumber">
                        </div>
                        
                        <div class="answerOption">
                            <select id="studentProgramme">
                                <option value="">Select Programme</option>'
                                <?php 
                                require_once '../session/index.php';
                                $department = $port->prepare("SELECT * FROM department");
                                $department->execute();
                                $departmentList = $department->fetchAll();
                                foreach($departmentList as $dl){
                                    echo '<option value="'.$dl['id'].'">'.$dl['name'].'</option>';
                                }
                                ?>
                            </select>
                        </div>
                        </div>
                        <div class="submitQA"> 
                        <input type="button" id="submitEnrol" value="Submit">  
                        </divd>
                    </form>


                </div>
            </div>
        </div>

        
    </body>
    
    <style>
        .enrolledD{
            width:100%;
            float:left;
            margin-top:10px;
            background:#f2f2f2;
            padding:20px;
            height: calc(100vh - 243px);
        }
        .data{
            width:100%;
            height:auto;
            padding:10px;
        }
        .sUnitcell{
            float:left;
            width:100%;
            padding:10px 20px;  
            height:auto;       
        }
        .sUnitblock{
            float:left;
            padding:10px;
            border-radius:10px;
            box-shadow:  inset 2px 2px 4px #BABECC, inset -3px -3px 6px  #FFF;
        }
        .sUnitblock p{
            float:left;
            padding:5px;
            width:100%;
            text-align:center;
        }
        
        .sUnitblock p:first-child{
            border-bottom:1px dotted #BABECC;
        }
        #sUnit{
            font-size:22px;
            font-weight:bold;
            padding: 5px;
        }
        .h1cell{
            padding:15px 20px;
            width:100%;
            float:left;
        }
        .h1cell i{
            
        }

        .addQdiv{
            width:100%;
            float:left;
            padding:10px 20px;
        }

        #addStudent{
            padding:10px;
            border-radius:10px;
            border:none;
            box-shadow:0 2px 4px rgba(0, 0, 0, 0.1);
            font-size:18px;
        }
        
        #addStudent i{
            color: inset 2px 2px 4px #BABECC, inset -3px -3px 6px  #FFF;;
        }

        *{
            box-sizing:border-box;
            margin:0px;
            padding:0px;
        }
        .studentModal{
            width:100%;
            height:100%;
            background:rgba(0, 0, 0, 0.5);
            position:absolute;
            top:0px;
            display:none;
        }
        .sM1{
            width:100%;
            height:100%;
        }
        .sM1head{
            width:100%;
            float:left;
            height:30px;
            padding:2px;
            background:#ffffff;
            border-bottom: 0.5px solid #f2f2f2;
        }
        .qMh1{
            width:100%;
            float:left;
            padding:10px 20px;
            text-align:center;
        }
        .qMh1 h1{
            font-size:24px;
            color:#333;
            text-shadow: 1px 1px #ec9393;
        }
        
        #closeQM{
            float:left;
            border:none;
            height:100%;
            border-radius:50%;
            padding:0px 5px;
            background:none;
        }
        
        #closeQM:hover{
            background:rgba(0,0,0,0.1);
        }

        .sM1content{
            float:left;
            width:100%;
            padding:10px;
            background:#ffffff;
        }
        .textarea{
            width:100%;
            float:left;
            padding:10px;
        }

        
        .textarea textarea{
            width:100%;
            height:100px;
            float:left;
            padding:10px;
            resize:none;
            border-radius:10px;
            border:none;
            background:rgba(0,0,0,0.1);
        }
        .optionList{
            width:100%;
            float:left;
        }
        .option{
            width:33.3%;
            float:left;
            padding:10px;
        }
        
        .option input{
            width:100%;
            float:left;
            padding:10px;
            border-radius:5px;
            border:none;
            background:rgba(0,0,0,0.05);
            box-shadow:  inset 2px 2px 4px #BABECC, inset -3px -3px 6px  #FFF;
        }
        .answerOption{
            width:33.3%;
            padding:10px;
            float:left;
            text-align:center;
        }
        
        .answerOption select{
            width:100%;
            padding:10px 20px;
            border-radius:5px;
            border:none;
            background:rgba(0,0,0,0.05);
            box-shadow:  inset 2px 2px 4px #BABECC, inset -3px -3px 6px  #FFF;
        }
        .submitQA{
            width:100%;
            float:left;
            padding:10px;
            text-align:center;
        }
        
        .submitQA input{
            width:auto;
            padding:10px 20px;
            text-align:center;
            border-radius:10px;
            border:none;
            background:#da2c2c;
            color:#ffffff;
        } 
         .submitQA input:hover{
            border:1px solid #da2c2c;
            background:#ffffff;
            color:#da2c2c;
        }

        .qList{
            width:100%;
            float:left;
            padding:5px;
        }
        .qSet{
            width:100%;
            float:left;
            padding:5px;
        }

        .qCall{
            width:auto;
            float:left;
            padding:5px;
            border-radius:10px;
            background:#ffffff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        
        .qCall p{
            width:100%;
            float:left;
            padding:5px;
            font-size:18px;
        }
        .qBtn{
            width:100%;
            float:left;
            padding:5px 20px;
        }
        
        .qBtn button{
            float:left;
            padding:5px;
            margin-right:20px;
            border-radius:5px;
            border:none;
            padding:3px 7px;
            background: #ffffff;
        }
        
        .qBtn button:first-child{
            background: #ffe033;
            color:#ffffff;
            box-shadow:inset 2px 2px 4px #ffd900, inset -3px -3px 6px #fff7cc;
        }
        
        .qBtn button:last-child{
            background: #da2c2c;
            color:#ffffff;
            box-shadow:inset 2px 2px 4px #c32222, inset -3px -3px 6px  #f7d4d4;
        }
        .qBtn button:first-child:hover{
            background: #ffe033;
            color:#ffffff;
            
        }
        
        .qBtn button:last-child:hover{
            background: #da2c2c;
            color:#ffffff;
        }
        .loader {
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid #da2c2c;
  width: 15px;
  height: 15px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
    </style>

    <script>

    const studentModal = document.querySelector('.studentModal');
    const addStudent = document.getElementById('addStudent');
    const closeQM = document.getElementById('closeQM');
    addStudent.addEventListener('click', ()=>{
        document.getElementById('addNewQ').reset();
        studentModal.style.display = "block";
    });
    closeQM.addEventListener('click', ()=>{
       closeQmodal();
    });

    function closeQmodal(){
        studentModal.style.display = "none"; 
    }
    const submitEnrol = document.getElementById('submitEnrol');
    const studentName = document.getElementById('studentName');
    const matricNum = document.getElementById('matricNumber');
    const studentProgramme = document.getElementById('studentProgramme');
    submitEnrol.addEventListener('click', ()=>{
        const studentname = studentName.value;
        const matricnum = matricNum.value;
        const program = studentProgramme.value;
        fetch('insert.php', {
            method: 'POST',
            header: {'content-Type':'application/json'},
            body: JSON.stringify({studentname:studentname, matricnum:matricnum, program:program})
        }).then(response=>response.json()).then(data =>{
            console.log(data);
            if(data.status =='success'){
                console.log(data.status);
                document.getElementById('addNewQ').reset();
                closeQmodal();
            }
        }).catch(error =>{
            console.error(error);
        })
    });
    function fetchQ(){
        const dtaDiv = document.querySelector(".data");
        fetch('students.php').then(response=>response.json()).then(data=>{
             const sUnit = document.getElementById('sUnit');
             if(data.length > 0){
                sUnit.innerHTML = data.length ;
            }
            else{
                sUnit.innerHTML = 'No registererd student';
            }
            data.forEach(element => {
               const dataDiv = document.createElement('div');
               dataDiv.classList.add('qList');
               dataDiv.innerHTML = `<div class="qSet" id="remove${element.id}"><div class="qCall"><p>${element.id}. ${element.name}</p><div class="qBtn"><button class="qedit" value="${element.id}"><i class="fa-solid fa-user-pen"></i> Edit</button><button class="studentDelete" value="${element.id}"><i class="fa-solid fa-user-minus"></i> Delete</button></div></div></div>`;
               dtaDiv.prepend(dataDiv);
              
            });
        }).catch(error=>{
            console.error(error);
        });
        }
        

    window.addEventListener('load', ()=>{
        fetchQ();
    })

    

    document.addEventListener('click', function(e){
        const qedit = e.target.closest('.qedit');
        const editStudent = e.target.closest('.editStudent');
        const studentDelete = e.target.closest('.studentDelete');
        if(qedit){
            let studentId = qedit.value;
            fetch('getStudent.php', {
                method:'POST',
                header:{'content-Type':'application/json'},
                body: JSON.stringify({studentId:studentId})
                
            }).then(response=>response.text()).then(data=>{
                studentModal.style.display = "block";
                document.getElementById('addNewQ').innerHTML = data;
            }).catch(error=>{
                console.log(error);
            })
        }
        if(editStudent){
            let editID = editStudent.getAttribute('data-id');
            let studentName = document.getElementById('studentName').value;
            let matricNum = document.getElementById('matricNumber').value;
            let studentProgramme = document.getElementById('studentProgramme').value;
            fetch('update.php', {
                method:'POST',
                header: {'content-Type':'application/json'},
                body: JSON.stringify({studentName:studentName, matricNum:matricNum, studentProgramme:studentProgramme, editID:editID})
            }).then(response=>response.json()).then(data=>{
                console.log(data);
            }).catch(error=>{
                console.log(error);
            })
        }
        if(studentDelete){
            studentDelete.innerHTML = '<div class="loader"></div>';
            let id = studentDelete.value;
            let that = "remove"+id;
            let toRemove = document.getElementById(that);
            fetch('delete.php',{
                method: 'POST',
                header: {'content-Type':'application/json'},
                body:JSON.stringify({id:id})
            }).then(response=>response.json()).then(data=>{
                if(data == "success"){
                    setTimeout(()=>{
                        toRemove.remove();
                    },1000)
                    
                }
                else{
                    qdelete.innerHTML = "Delete";
                }
                console.log(data);
            }).catch(error=>{
                console.log(error);
            })
            
        }

    })
    </script>
</html>