<?php
include '../session/index.php';
$fetchALL = $port->prepare("SELECT * FROM students ORDER BY id DESC");
$fetchALL->execute();
$response = $fetchALL->fetchAll();
echo json_encode($response);

?>