<?php
$head ="
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <link rel='icon' href='../logo.ico'>
    <title>MLU CBT</title>
     <link href='../assets/fontawesome/css/fontawesome.css' rel='stylesheet' />
  <link href='../assets/fontawesome/css/brands.css' rel='stylesheet' />
  <link href='../assets/fontawesome/css/solid.css' rel='stylesheet' />
  
  </head>
";
print($head);
?>
<style>
*{
    box-sizing:border-box;
    margin:0px;
    font-family: Arial, sans-serif;
    padding: 0px;

}
</style>