<?php
require_once('../session/index.php');

if(isset($_SESSION['user'])){
    header('Location: ../question');
}

$cbt_login="";
$cbt_login .= "<!DOCTYPE html>
<html lang='en'>";
include "../includes/head.php";
$cbt_login .="
<body>
<div class='container'>
<div class='main_content'>
<div class='logocell'>
<img src='../samuelAdemoroti.png' alt='Logo' class='logo'>
</div>";
if(isset($_SESSION['success'])){
$cbt_login .= "<div class='successdiv'><p class='success'>" . $_SESSION['success'] . "<span id='closes'>x</span></p></div>";
	unset($_SESSION['success']);
}
if(isset($_SESSION['error'])) {
    $cbt_login .=  "<div class='errordiv'><p class='error'>" . $_SESSION['error'] . " <span id='closee'>x</span></p></div>";
    unset($_SESSION['error']);
}
$cbt_login .= "<form method='post' action='../initialize/'>";
$cbt_login .= "<input type='text' name='matricnumber' placeholder='Enter Matric number' /><input type='password' name='password' placeholder='Enter password' /><input type='hidden' name='type' value='login'/><input type='submit' value='Login' />";
$cbt_login .= "</form>";
$cbt_login .= "
</div>
</div>
</body>";
print($cbt_login);


?>

<style>
    .container {
        width: 100%;
        height:100%;
        float:left;
        justify-content:center;
        align-items:center;
        display:flex;
    }

    .main_content{
        border: 1px solid rgba(0,0,0,0.05);
        padding: 20px;
        border-radius: 10px;
        background:#fbe9e9;
        box-shadow:2px 2px 4px rgba(0,0,0,0.05);
    }

    .logocell {
        width: 100%;
        float:left;
        text-align:center;

    }
    .logo {
        width: 100px;
        height: auto;
        margin-bottom: 20px;
    }
    input[type="text"],
    input[type="password"] {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        border: none;
        border-radius: 5px;
        box-shadow: inset 2px 2px 5px #f2f2f2, inset 2px 2px 4px #ffffff;
    }
    input[type="submit"] {
        width: 100%;
        padding: 10px;
        background-color: #da2c2c;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .errordiv{
        display: flex;
        margin: 10px 0;
        padding: 10px;
        border-radius: 5px;
        justify-content:center;
        align-items:center;
        
    }

    .error {
        color: red;
        background-color: #f8d7da;
        border: 1px solid #ffffff;
        border-radius: 5px;
        text-align: center;
        padding: 10px 20px;
        position:relative;
    }
    
    .successdiv{
        margin: 10px 0;
        padding: 10px;
        border-radius: 5px;
        justify-content:center;
        align-items:center;
        display: flex;
    }

    .success {
        color: green;
        font-weight: bold; 
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        border-radius: 5px;
        text-align: center;
        padding: 10px 20px;
    }

    #closee, #closes{
        background:#ffffff;
        padding: 2px 5px;
        border-radius:5px;
        position:absolute;
        top:-10;
        right:-10;
    }
</style>
<script>
    const closeError = document.getElementById('closee');
    const errorDiv = document.querySelector(".errordiv");
    closeError.addEventListener('click', ()=>{
        errorDiv.style.display = "none";
    });

const closeSuccess = document.getElementById('closes');
const successDiv = document.querySelector('.successdiv');
closeSuccess.addEventListener('click', ()=>{
    successDiv.style.display = "none";
    console.log('Developed by: Samuel D Ademoroti');
});
</script>

