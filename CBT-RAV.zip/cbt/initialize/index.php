<?php
require_once('../session/index.php');
require_once('../classify/index.php');

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    switch($_POST['type']){
        case 'login':
            $mn = $_POST['matricnumber'];
            $key = $_POST['password'];
            $classify->Login($mn, $key);
            break;
        case 'signup':
            $classify->Signup();
            break;
        case 'setpassword':
            $key = $_POST['password'];
            $classify->Setpassword($key);
            break;
        default:
            echo 'Invalid request type';
            break;
    }
}
else {
    if(isset($_SESSION['user'])){
        header('Location: ../question/');
        exit();
    } else {
        header('Location: ../index.php');
        exit();
    }
}
?>