
<script>
    alert("Hi");
window.addEventListener('beforeunload', function(e){
    e.preventDefault();
    e.returnValue ='';
    alert("Hi");
    console.log('Are you sure you want to leave?');
});
</script>