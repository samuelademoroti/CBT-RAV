<?php
$video = "videos/a.mp4";
$command= "ffmpeg";
exec($command, $output, $return_code);
print_r($output);

?>