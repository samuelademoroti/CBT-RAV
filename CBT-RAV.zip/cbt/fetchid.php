<?php
require_once('session/index.php');


 $query = $port->prepare("SELECT * FROM password");
 $query->execute();
 $res = $query->fetchAll();
 
 $a = "wifiwey";
 $arraycolum = array_column($res, 'auth_key');
 if(in_array($a, $arraycolum)){
    echo "Key exists in the array.";
    $main_key =  $res[array_key_last($res)]['auth_key'];
    if($a == $main_key){
        echo 'password is correct';
    }
    else{
        echo 'password has been changed ';
    }
   
 }
 else{
    echo "Key does not exist in the array.";
 }
 ?>