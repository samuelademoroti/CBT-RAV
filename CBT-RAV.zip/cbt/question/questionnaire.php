<?php
include('../session/index.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   if (isset($_FILES['video'])) {
    $name = $_SESSION['user']['id'];
    $uploadDir = '../videos/'.$name.'/';
    $uploadFile = $uploadDir . basename($_FILES['video']['name']);
    if(is_dir($uploadDir)){
      if (move_uploaded_file($_FILES['video']['tmp_name'], $uploadFile)) {
        $status = 'success';
      }
      else {
        $status= 'Error';
      }
    }
    else{
      mkdir($uploadDir, 0777, true);
      $uploadDir = '../videos/'.$name.'/';
      $uploadFile = $uploadDir . basename($_FILES['video']['name']);
      $_SESSION['video'] = $uploadFile;
      if (move_uploaded_file($_FILES['video']['tmp_name'], $uploadFile)) {
        $status = 'success';
      } 
      else {
        $status=  'Error';
      }
    }
    $totalScore = 0;
    $totalResult = $port->prepare('SELECT score FROM answers WHERE student_id=:student_id');
    $totalResult->execute(['student_id'=>$name]);
    foreach($totalResult as $addScored){
      $totalScore += $addScored['score'];
    }
    
    $final = $port->prepare('INSERT INTO final_result (student_id, score) VALUES (:student_id, :score)');
    $final->execute(['student_id'=>$name, 'score'=>$totalScore]);
  
    echo json_encode(['status' => $status]);
  }
  
  else{
    header('Content-Type:application/json');
    $data = file_get_contents('php://input');
    $datas = json_decode($data,true);
    $question_id = $datas['question_id'];
    $answer = $datas['answer'];
    $stmt = $port->prepare("SELECT correct_option FROM questions WHERE id=:i");
    $stmt->execute(["i"=> $question_id]);
    $question = $stmt->fetch();
    if($question['correct_option'] == $answer){
      $score = 1;
    }
    else{
      $score = 0;
    }
  
    $checkExistance = $port->prepare("SELECT * FROM answers WHERE question_id=:question_id AND student_id=:student_id");
    $checkExistance->execute(["question_id"=>$question_id,"student_id"=>$_SESSION['user']['id']]);
    if ($checkExistance->rowCount() > 0) {
      $update = $port->prepare("UPDATE answers SET answer=:answer, score=:score WHERE question_id=:question_id AND student_id=:student_id");
      $update->execute([
          'answer' => $answer,
          'score' => $score,
          'question_id' => $question_id,
          'student_id' => $_SESSION['user']['id']
      ]);
      echo json_encode(['status' => 'success', 'message' => 'Answer updated successfully']);
    } 
    else {
        $insert = $port->prepare("INSERT INTO answers (question_id, answer, student_id, score) VALUES (:question_id, :answer, :student_id, :score)");
        $insert->execute([
            'question_id' => $question_id,
            'answer' => $answer,
            'score' => $score,
            'student_id' => $_SESSION['user']['id']
        ]);
        echo json_encode(['status' => 'success', 'message' => 'Answer saved successfully']);
    }

    

  }


 

} 
else {
    // Fetch one question at a time
    $question_id = isset($_GET['question_id']) ? intval($_GET['question_id']) : 1;
    $stmt = $port->prepare("SELECT id, question, option_a, option_b, option_c, option_d FROM questions WHERE id=:i");
    $stmt->execute(["i"=> $question_id]);
    $question = $stmt->fetch();
    $ifAnswered = $port->prepare("SELECT answer FROM answers WHERE question_id=:i AND student_id=:student_id");
    $ifAnswered->execute(["i"=> $question_id, "student_id"=>$_SESSION['user']['id']]);
    $ifAnsweredResult = $ifAnswered->fetch();
    if ($ifAnsweredResult) {
       $result = array_merge($question,$ifAnsweredResult);
    } else {
        $result = $question;
    }
    
    header('Content-Type: application/json');
    echo json_encode($result);
}
?>