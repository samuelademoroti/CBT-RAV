<?php
require_once('../session/index.php');
if(!isset($_SESSION['user'])){
header('Location: ../index.php');
exit();
}
else{
    $stmt = $port->prepare('SELECT *, COUNT(*) AS numrow FROM final_result WHERE student_id=:id');
    $stmt->execute(['id'=>$_SESSION['user']['id']]);
    $score = $stmt->fetch();
    if($score['numrow'] > 0){
        header('Location: ../score/');
    }

}

$question = '';
$question .='
<!DOCTYPE html>
<html lang="en">';
include "../includes/head.php"; 
$question .='
<body>
<div class="logocell">
<img src="../samuelAdemoroti.png" alt="Logo" class="logo">
</div>
<div class="top">
    <div class="studentInfo">
        <div class="name"><p>Name:</p> <p>'.$_SESSION['user']['name'].'</p></div>
        <div class="mnum"><p>Matriculation Number: </p> <p>'.$_SESSION['user']['matric_number'].'</p></div>
        <div class="cname"><p>Course: </p> <p>COS 102 Introduction to Computing</p></div>
    </div>

    <div class="examTime">
        <div class="iCase"><i class="fa-regular fa-alarm-clock"></i></div>
        <p id="xTime">1 Minutes<p>
    </div>
</div>

<div class="questionPaper">
    <div id="question-container"></div>
    <div class="question_paper_button">
    <button id="previous-question" style="display: none;">Previous Question</button>
    <button id="next-question" style="display: none;">Next Question</button>
    <button id="submit-exam" style="display: none;">Submit Exam</button>
    </div>
    <video id="webcam-video" hidden muted></video>
    <video id="recorded-video" controls hidden></video>
</div>
</body>
';

print($question);

?>
    <style>
       
    .logocell {
        width: 100%;
        float:left;
        text-align:center;

    }
    .logo {
        width: 150px;
        height: auto;
    }
        .iCase{
            width:100%;
            float:left;
            display:flex;
            justify-content:center;
            align-items:center;
            padding: 10px;
        }

        .iCase i{
            font-size:50px;
        }

        #xTime{
            width:100%;
            float:left;
            text-align:center;
            font-size:20px;
        }

        .name{
            float:left;
            width:100%;

        }

        .cname{
            float:left;
            width:100%;
        }

        .mnum{
            float:left;
            width:100%;
        }
        .name p:first-child{
            float:left;
            height:40px;
            padding: 4px 10px 0 0;
            font-weight:bold;
            font-size:20px;
            color:#570f0f;
        }
         .cname p:first-child, .mnum p:first-child{
            float:left;
            height:30px;
            padding: 2px 10px 0 0;
            font-weight:bold;
            color:#570f0f;
        }
        .name p:last-child{
            float:left;
            font-size:25px;
            height:40px;
        }
        .cname p:last-child, .mnum p:last-child{
            float:left;
            font-size:20px;
            height:30px;
        }


        .top{
            width:100%;
            float:left;
            padding:10px;
        }

        .studentInfo{
            width:80%;
            float:left; 
            padding: 20px;
        }

        .examTime{
            width:20%;
            float:left;
            padding:20px 0 0 0;
        }

        .questionPaper{
            width:100%;
            float:left;
        }

        #question-container{
            margin: 20px;
            padding: 10px;
            border: 1px solid rgba(251, 233, 233, 1);
            border-radius: 5px;
            background-color: #ffffff;
        }
        #question-container p{
            font-size: 20px;
            margin: 10px 0;
        }
        
        #question-container label {
            font-size:18px;
        }
        #question-container label input[type='radio']{
            accent-color:red;
        }
        #next-question, #previous-question, #submit-exam {
            margin: 10px;
            padding: 10px 20px;
            background-color: #da2c2c;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .question_paper_button{
            width:100%;
            float:left;
            justify-content:space-between;
            display:flex;
            padding:10px;
        }
    </style>

    <script>
        let currentQuestionId = 1;
        let mediaRecorder;
        let recordedChunks = [];
        let videoBlob;

        let minTime = 0;
        let secTime = 0;
        let hourTime = 0;
        const xtime = document.getElementById('xTime');
        setInterval(() => {
            secTime++;
            timeUpdate()
        }, 1000);
//I REMOVED SOME, IF YOU ARE A DEV COMPLETE IT ELSE.. ITS MY WORK CALL ME
        function timeUpdate(){
            xtime.innerHTML = hourTime+':'+minTime+':'+secTime;
            if(secTime == 60){
                minTime++;
                //store incase fool refresh
            }
            if(minTime == 60){
                hourTime++;
            }
        }
        // Fetch and display one question at a time
        function fetchQuestion() {
            fetch(`questionnaire.php?question_id=${currentQuestionId}`)
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById('question-container');
                    container.innerHTML = `
                        <p>${currentQuestionId}. ${data.question}</p>
                        <label><input type="radio" name="answer" value="A"> ${data.option_a}</label><br>
                        <label><input type="radio" name="answer" value="B"> ${data.option_b}</label><br>
                        <label><input type="radio" name="answer" value="C"> ${data.option_c}</label><br>
                        <label><input type="radio" name="answer" value="D"> ${data.option_d}</label><br>
                    `;
                     if(data.answer){
                        document.querySelector(`input[name="answer"][value="${data.answer}"]`).checked = true;
                    } else {
                        const inputs = container.querySelectorAll('input[type="radio"]');
                        inputs.forEach(input => input.checked = false);
                    }
                    document.getElementById('next-question').style.display = 'block';
                    document.getElementById('previous-question').style.display = currentQuestionId > 1 ? 'block' : 'none';
                    
             //Here you can set == to count of total number,. HEY! YOU ARE SMART THO
                    if (currentQuestionId === 4) {
                        document.getElementById('next-question').style.display = 'none';
                        document.getElementById('submit-exam').style.display = 'block';
                    }
                    else{
                        document.getElementById('submit-exam').style.display = 'none';
                    }
                });
        }
          
        function submitQuestion(q,a) {
            fetch('questionnaire.php',{
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({question_id:q, answer:a})
            }).then(response=>response.json()).then(data=>{
                console.log('Question submitted:', data);
            }).catch(error=>{
                console.error('Error',error);
            })
        }

        // Start webcam recording and display live feed
        async function startRecording() {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
                mediaRecorder = new MediaRecorder(stream);
                mediaRecorder.ondataavailable = event => recordedChunks.push(event.data);
                mediaRecorder.start();
        
                const webcamVideo = document.getElementById('webcam-video');
                webcamVideo.srcObject = stream;
                webcamVideo.play();
            } catch (err) {
                console.error('Error accessing webcam:', err);
                window.location = '../permission/';
            }
        }

        // Stop recording and save video
        function stopRecording() {
            mediaRecorder.onstop = () => {
                videoBlob = new Blob(recordedChunks, { type: 'video/webm; codecs=vp9' });
                const video = document.getElementById('recorded-video');
                video.src = URL.createObjectURL(videoBlob);
                console.log(`Video Blob Size: ${videoBlob.size}`);
                recordedChunks = []; // Replace with actual user ID
                const formData = new FormData();
                formData.append('video', videoBlob, `${Date.now()}.webm`);

                fetch('questionnaire.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    console.log(data.status);
                    if(data.status =='success'){
                        console.log(data);
                    console.log('Server Response:', data);
                    window.location = '../score/';
                    }
                    else{
                    console.log('Server Response:', data);
                    }
                    
                   
                })
                .catch(error => {
                    console.error('Error uploading video:', error);
                    
                });
            };
            mediaRecorder.stop();
        }

        // Save answer and move to the next question
        document.getElementById('next-question').addEventListener('click', () => {
            const selectedAnswer = document.querySelector('input[name="answer"]:checked');
            var saValue = selectedAnswer ? selectedAnswer.value : null;
             if (saValue) {
                    submitQuestion(currentQuestionId, saValue);
                }
                else{
                }
                currentQuestionId++;
                fetchQuestion();
           
        });

        // Move to the previous question
        document.getElementById('previous-question').addEventListener('click', () => {
            const selectedAnswer = document.querySelector('input[name="answer"]:checked');
            var saValue = selectedAnswer ? selectedAnswer.value : null;
            
            if (currentQuestionId > 1) {
                if (saValue) {
                    submitQuestion(currentQuestionId, saValue);
                }
                else{
                }
                currentQuestionId--;
                fetchQuestion();
            }
        });

        // Submit exam
        document.getElementById('submit-exam').addEventListener('click', () => {
            const selectedAnswer = document.querySelector('input[name="answer"]:checked');
            var saValue = selectedAnswer ? selectedAnswer.value : null;
             if (saValue) {
                    submitQuestion(currentQuestionId, saValue);
                }
                else{
                }
            stopRecording();
           
        });

        // Initialize exam
        
        document.addEventListener('DOMContentLoaded',()=>{
        fetchQuestion();
        startRecording();
        });
    </script>

</html>