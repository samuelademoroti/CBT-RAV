<?php
class Classify{
    private $mn;
    private $key;
    public $user;

     function Login($mn, $key){
        global $port;
        $query = $port->prepare("SELECT *, COUNT(*) AS numrow FROM students WHERE matric_number=:matricnumber");
        $query->execute(['matricnumber' => $mn]);
        $user = $query->fetch();
        if($user['numrow'] > 0){    
            $passwordCheck = $port->prepare("SELECT * FROM password where student_id=:student_id");
            $passwordCheck->execute(['student_id' => $user['id']]);
            $pKey = $passwordCheck->fetchAll();
            $pList = array_column($pKey, 'auth_key');

            if(empty($pList)){
                $_SESSION['user'] = $user;
                header('Location: ../password/');
                exit();
            }else{
                if(in_array($key, $pList)){
                    $pData = $pKey[array_key_last($pKey)]['auth_key'];
                    switch($key){
                        case $pData:
                            $_SESSION['user'] = $user;
                            header('Location: ../question');
                            break;
                            //github samuelademoroti
                        default:
                            $_SESSION['error'] = 'Password has been changed';
                            header('Location: ../index.php');
                            exit();
                    }
                }
                else{
                    $_SESSION['error'] = "Password incorrect";
                    header('Location: ../index.php');
                    exit();
                }
            }
        } else {
            $_SESSION['error'] = "Invalid login credentials";
            header('Location: ../index.php');
            exit();
        }


    }

function Setpassword($key){
    global $port;
    $inserPassword = $port->prepare("INSERT INTO password (auth_key, student_id) VALUES (:auth_key, :student_id)");
    $inserPassword->execute(["auth_key"=> $key, "student_id"=> $_SESSION['user']['id']]);
    $_SESSION['success'] = "Password has been set successfully";
    unset($_SESSION["user"]);
    header('Location: ../index.php');
    exit();

}

    function Signup(){
    global $port;
    $checkQuery = $port->prepare("SELECT COUNT(*) AS numrow FROM users WHERE matric_number=:matricnumber");
    $checkQuery->execute(['matricnumber' => $_POST['matricnumber']]);
    $check = $checkQuery->fetch();
    if($check['numrow'] > 0){
        $_SESSION['error'] = "You have already Signed Up";
        header('Location: ../signup/');
        exit();
    } else {
        $query = $port->prepare("INSERT INTO users (matric_number, first_name, last_name, department, auth_key) VALUES(:matric_number, :first_name, :last_name, :department, :auth_key)");
        $query->execute(['matric_number'=>$_POST['matricnumber'], 'first_name'=>$_POST['firstname'], 'last_name'=>$_POST['lastname'], 'department'=>$_POST['department'], 'auth_key'=>$_POST['password']]);
        $_SESSION['success'] = "You have successfully Registered";
        header('Location: ../index.php');
        exit();
}
    }
}
$classify = new Classify();

?>