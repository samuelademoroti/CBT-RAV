<?php
include '../includes/head.php';
$staff = '';
$staff .= '<a href="../create/">Create Exam</a>
<a href="../enrol/">Enrol student</a>
<a href="../question/">Add Question</a>
';
print($staff);

?>