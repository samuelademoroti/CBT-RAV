<?php
$video = "videos/e.mp4";
$ffmpegpath = "C:/ffmpeg/bin/ffmpeg.exe";
// Construct the command using the full path
$command = "{$ffmpegpath} -i {$video} -af 'volumedetect' -f null - 2>&1";
$mean = null;
$max = null;
exec($command, $output, $return_code);
foreach($output as $row){
    if(strpos($row, 'mean_volume')){
        if(preg_match("/mean_volume: ([-0-9.]+) dB/", $row, $match)){
            $mean = $match[1];
        }
    }
    if(strpos($row, 'max_volume')){
        if(preg_match("/max_volume: ([-0-9.]+) dB/", $row, $maxmatch)){
            $max =$maxmatch[1];
        }
    }

}
if($mean <= -40.00 && $mean >= -60.00 ){
 echo "Okay".$mean;
}else{
    echo 'You Cheated'.$mean;
}

if($max <= -30.00 && $max >= -40.0 ){
 echo "Okay".$max;
}else{
    echo 'You Cheated'.$max;
}

?>