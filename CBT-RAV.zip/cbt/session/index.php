<?php


if(file_exists('config/index.php')){
   include('config/index.php');
}else{
if(file_exists('../config/index.php')){
    include('../config/index.php');
}
}
session_start();
$port = $network->connect();

?>