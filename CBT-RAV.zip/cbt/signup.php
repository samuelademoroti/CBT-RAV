<?php
require_once('session/index.php');

$signup_page = "";
$signup_page .= "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>CBT Signup</title>
</head>";



$signup_page .= "<body>
<h1>CBT Signup</h1>";
if(isset($_SESSION['error'])){
    $signup_page .= "<p style='color: red;'>".$_SESSION['error']."</p>";
    unset($_SESSION['error']);
}
$signup_page .="
<form method='post' action='login.php'>
<input type='hidden' name='type' value='signup'>
    <label for='firstname'>First Name:</label>
    <input type='text' id='firstname' name='firstname' required><br>
    <label for='flasstname'>Last Name:</label>
    <input type='text' id='lastname' name='lastname' required><br>
    <label for='matricnumber'>Matric Number:</label>
    <input type='text' id='matricnumber' name='matricnumber' required><br>
    <label for='department'>Department:</label>
    <select id='department' name='department' required>
        <option value=''>Select Department</option>
    ";
    $department = $port->prepare("SELECT * FROM department");
$department->execute();
foreach($department as $dept){
    $signup_page .= "<option value='".$dept['id']."'>".$dept['name']."</option>";
}
    
    $signup_page .="
    </select>
    <br>
    <label for='password'>Password:</label>
    <input type='password' id='password' name='password' required><br>
    
    <button type='submit' name='type' value='signup'>Sign Up</button>
</body>";


?>
<?php  print $signup_page; ?>
<style>
h1{
    text-align: center;
    color: #333;
}
*{
    box-sizing:border-box;
    padding: 0;
    margin: 0;
    font-family: Arial, sans-serif;
}
form{
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 5px;
}
form input, form select, form button {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
}

</style>